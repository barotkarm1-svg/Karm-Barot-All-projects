# Book AI Platform MVP

This project ingests books, stores and manages them in a backend, generates AI-style insights, supports Q&A over book content, and exposes features through REST APIs with a simple React frontend.

## Stack

- Backend: FastAPI + SQLAlchemy
- Database: PostgreSQL
- Frontend: React + Vite
- AI layer: deterministic mock embedding + retrieval pipeline (provider abstraction ready)

## Run Locally

1. Copy environment file:
   - `copy .env.example .env` (Windows)
2. Start infrastructure:
   - `docker compose -f infra/docker-compose.yml up --build`
3. Backend API:
   - `http://localhost:8000/docs`
4. Frontend:
   - In `frontend/`: `npm install && npm run dev`

## REST Endpoints

- `POST /books/ingest`
- `GET /books`
- `GET /books/{id}`
- `GET /books/{id}/insights`
- `POST /books/{id}/insights/regenerate`
- `POST /qa/ask`
- `GET /qa/sessions/{id}`

## Example Ingest Payload

```json
{
  "title": "Example Book",
  "author": "Jane Doe",
  "description": "Short description",
  "full_text": "Paste full book or chapter text here"
}
```

## Notes

- `backend/migrations/001_init.sql` contains the initial database migration SQL.
- Current embeddings/insights are mock deterministic logic for MVP speed; you can swap in real LLM/embedding providers in `backend/app/services`.
