import { useEffect, useState } from "react";

const API = import.meta.env.VITE_API_URL || "http://localhost:8000";

export default function App() {
  const [books, setBooks] = useState([]);
  const [selectedBook, setSelectedBook] = useState(null);
  const [insights, setInsights] = useState([]);
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState(null);
  const [form, setForm] = useState({ title: "", author: "", description: "", full_text: "" });

  async function loadBooks() {
    const res = await fetch(`${API}/books`);
    setBooks(await res.json());
  }

  async function ingestBook(e) {
    e.preventDefault();
    await fetch(`${API}/books/ingest`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(form),
    });
    setForm({ title: "", author: "", description: "", full_text: "" });
    loadBooks();
  }

  async function loadInsights(bookId) {
    const res = await fetch(`${API}/books/${bookId}/insights`);
    setInsights(await res.json());
  }

  async function regenerateInsights(bookId) {
    await fetch(`${API}/books/${bookId}/insights/regenerate`, { method: "POST" });
    loadInsights(bookId);
  }

  async function askQuestion() {
    const payload = { question, book_ids: selectedBook ? [selectedBook.id] : [] };
    const res = await fetch(`${API}/qa/ask`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    setAnswer(await res.json());
  }

  useEffect(() => {
    loadBooks();
  }, []);

  return (
    <div className="container">
      <h1>Book AI Platform MVP</h1>
      <section>
        <h2>Ingest Book</h2>
        <form onSubmit={ingestBook} className="grid">
          <input placeholder="Title" value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} required />
          <input placeholder="Author" value={form.author} onChange={(e) => setForm({ ...form, author: e.target.value })} />
          <textarea placeholder="Description" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
          <textarea placeholder="Full text content" value={form.full_text} onChange={(e) => setForm({ ...form, full_text: e.target.value })} required />
          <button type="submit">Ingest</button>
        </form>
      </section>
      <section>
        <h2>Books</h2>
        <ul>
          {books.map((book) => (
            <li key={book.id}>
              <button
                onClick={() => {
                  setSelectedBook(book);
                  loadInsights(book.id);
                }}
              >
                {book.title} by {book.author}
              </button>
            </li>
          ))}
        </ul>
      </section>
      <section>
        <h2>Insights</h2>
        {selectedBook && <button onClick={() => regenerateInsights(selectedBook.id)}>Regenerate Insights</button>}
        {insights.map((i) => (
          <div key={i.id} className="card">
            <p><strong>Summary:</strong> {i.summary}</p>
            <p><strong>Themes:</strong> {i.themes.join(", ")}</p>
            <p><strong>Recommendations:</strong> {i.recommendations.join(", ") || "None yet"}</p>
          </div>
        ))}
      </section>
      <section>
        <h2>Ask Questions</h2>
        <input value={question} onChange={(e) => setQuestion(e.target.value)} placeholder="Ask about books..." />
        <button onClick={askQuestion}>Ask</button>
        {answer && (
          <div className="card">
            <p>{answer.answer}</p>
            <small>Citations: {answer.citations.length}</small>
          </div>
        )}
      </section>
    </div>
  );
}
