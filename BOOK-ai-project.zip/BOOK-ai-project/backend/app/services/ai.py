import math
from collections import Counter

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.models import Book, BookChunk, Insight, QaMessage, QaSession
from app.services.ingestion import embed_text


def cosine_similarity(a: list[float], b: list[float]) -> float:
    dot = sum(x * y for x, y in zip(a, b))
    mag_a = math.sqrt(sum(x * x for x in a))
    mag_b = math.sqrt(sum(y * y for y in b))
    if mag_a == 0 or mag_b == 0:
        return 0.0
    return dot / (mag_a * mag_b)


def generate_insight(db: Session, book_id: int) -> Insight:
    book = db.get(Book, book_id)
    if not book:
        raise ValueError("Book not found")

    words = [w.strip(".,!?;:()[]").lower() for w in book.full_text.split()]
    filtered = [w for w in words if len(w) > 4]
    top_themes = [w for w, _ in Counter(filtered).most_common(5)] or ["general"]

    summary = book.full_text[:600]
    if len(book.full_text) > 600:
        summary += "..."

    others = db.scalars(select(Book).where(Book.id != book.id).limit(20)).all()
    target = embed_text(book.full_text[:1200])
    ranked = []
    for other in others:
        ranked.append((other.title, cosine_similarity(target, embed_text(other.full_text[:1200]))))
    recommendations = [title for title, _ in sorted(ranked, key=lambda t: t[1], reverse=True)[:3]]

    insight = Insight(
        book_id=book.id,
        summary=summary,
        themes=top_themes,
        recommendations=recommendations,
        model_name="mock-insight-v1",
    )
    db.add(insight)
    db.commit()
    db.refresh(insight)
    return insight


def ask_question(db: Session, question: str, book_ids: list[int], session_id: int | None):
    session = db.get(QaSession, session_id) if session_id else None
    if not session:
        session = QaSession(title=question[:40])
        db.add(session)
        db.flush()

    q_embed = embed_text(question)
    stmt = select(BookChunk)
    if book_ids:
        stmt = stmt.where(BookChunk.book_id.in_(book_ids))
    chunks = db.scalars(stmt.limit(200)).all()
    ranked = sorted(chunks, key=lambda c: cosine_similarity(q_embed, c.embedding), reverse=True)[:3]

    citations = [{"book_id": c.book_id, "chunk_id": c.id, "snippet": c.content[:180]} for c in ranked]
    if ranked:
        answer = "Based on the most relevant sections: " + " ".join([c.content[:200] for c in ranked])
    else:
        answer = "I could not find supporting passages in the current library."

    db.add(QaMessage(session_id=session.id, role="user", content=question, citations=[]))
    db.add(QaMessage(session_id=session.id, role="assistant", content=answer, citations=citations))
    db.commit()
    return session.id, answer, citations
