import hashlib
from typing import Iterable

import httpx
from sqlalchemy.orm import Session

from app.core.config import settings
from app.models.models import Book, BookChunk
from app.schemas.schemas import BookIngestRequest


def chunk_text(text: str, size: int, overlap: int) -> Iterable[str]:
    if not text:
        return []
    chunks = []
    start = 0
    while start < len(text):
        end = min(start + size, len(text))
        chunks.append(text[start:end])
        if end == len(text):
            break
        start = max(0, end - overlap)
    return chunks


def embed_text(text: str) -> list[float]:
    digest = hashlib.sha256(text.encode("utf-8")).digest()
    vector = [b / 255 for b in digest[: settings.embedding_size]]
    if len(vector) < settings.embedding_size:
        vector += [0.0] * (settings.embedding_size - len(vector))
    return vector


async def fetch_text_from_source(url: str) -> str:
    async with httpx.AsyncClient(timeout=20) as client:
        response = await client.get(url)
        response.raise_for_status()
    return response.text


async def ingest_book(db: Session, payload: BookIngestRequest) -> Book:
    full_text = payload.full_text or ""
    if not full_text and payload.source_url:
        full_text = await fetch_text_from_source(payload.source_url)
    if not full_text:
        raise ValueError("Either full_text or a valid source_url is required.")

    book = Book(
        title=payload.title,
        author=payload.author,
        isbn=payload.isbn,
        description=payload.description,
        full_text=full_text,
    )
    db.add(book)
    db.flush()

    for idx, c in enumerate(chunk_text(full_text, settings.chunk_size, settings.chunk_overlap)):
        db.add(BookChunk(book_id=book.id, chunk_index=idx, content=c, embedding=embed_text(c)))

    db.commit()
    db.refresh(book)
    return book
