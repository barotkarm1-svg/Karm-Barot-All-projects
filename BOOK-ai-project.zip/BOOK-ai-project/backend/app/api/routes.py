from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.models.models import Book, Insight, QaMessage
from app.schemas.schemas import AskRequest, AskResponse, BookIngestRequest, BookOut, InsightOut, SessionMessageOut
from app.services.ai import ask_question, generate_insight
from app.services.ingestion import ingest_book

router = APIRouter()


@router.get("/health")
def health():
    return {"status": "ok"}


@router.post("/books/ingest", response_model=BookOut)
async def books_ingest(payload: BookIngestRequest, db: Session = Depends(get_db)):
    try:
        return await ingest_book(db, payload)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.get("/books", response_model=list[BookOut])
def list_books(db: Session = Depends(get_db)):
    return db.scalars(select(Book).order_by(Book.created_at.desc())).all()


@router.get("/books/{book_id}", response_model=BookOut)
def get_book(book_id: int, db: Session = Depends(get_db)):
    book = db.get(Book, book_id)
    if not book:
        raise HTTPException(status_code=404, detail="Book not found")
    return book


@router.get("/books/{book_id}/insights", response_model=list[InsightOut])
def get_insights(book_id: int, db: Session = Depends(get_db)):
    return db.scalars(
        select(Insight).where(Insight.book_id == book_id).order_by(Insight.created_at.desc())
    ).all()


@router.post("/books/{book_id}/insights/regenerate", response_model=InsightOut)
def regenerate_insight(book_id: int, db: Session = Depends(get_db)):
    try:
        return generate_insight(db, book_id)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.post("/qa/ask", response_model=AskResponse)
def ask(payload: AskRequest, db: Session = Depends(get_db)):
    session_id, answer, citations = ask_question(db, payload.question, payload.book_ids, payload.session_id)
    return AskResponse(session_id=session_id, answer=answer, citations=citations)


@router.get("/qa/sessions/{session_id}", response_model=list[SessionMessageOut])
def get_session(session_id: int, db: Session = Depends(get_db)):
    return db.scalars(
        select(QaMessage).where(QaMessage.session_id == session_id).order_by(QaMessage.created_at.asc())
    ).all()
