from fastapi import FastAPI

from app.api.routes import router
from app.core.config import settings
from app.core.database import Base, engine
from app.models import models  # noqa: F401

app = FastAPI(title=settings.app_name)
app.include_router(router)


@app.on_event("startup")
def startup():
    Base.metadata.create_all(bind=engine)
