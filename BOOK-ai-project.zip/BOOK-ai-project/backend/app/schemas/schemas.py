from datetime import datetime

from pydantic import BaseModel, Field


class BookIngestRequest(BaseModel):
    title: str
    author: str = "Unknown"
    isbn: str | None = None
    description: str | None = None
    full_text: str | None = None
    source_url: str | None = None


class BookOut(BaseModel):
    id: int
    title: str
    author: str
    isbn: str | None
    description: str | None
    created_at: datetime

    class Config:
        from_attributes = True


class InsightOut(BaseModel):
    id: int
    book_id: int
    summary: str
    themes: list[str]
    recommendations: list[str]
    model_name: str
    created_at: datetime

    class Config:
        from_attributes = True


class AskRequest(BaseModel):
    question: str = Field(min_length=3)
    book_ids: list[int] = []
    session_id: int | None = None


class AskResponse(BaseModel):
    session_id: int
    answer: str
    citations: list[dict]


class SessionMessageOut(BaseModel):
    role: str
    content: str
    citations: list[dict]
    created_at: datetime

    class Config:
        from_attributes = True
