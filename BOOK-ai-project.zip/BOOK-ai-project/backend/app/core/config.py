from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    app_name: str = "Book AI Platform"
    database_url: str = "postgresql+psycopg://bookai:bookai@localhost:5432/bookai"
    llm_provider: str = "mock"
    llm_api_key: str = ""
    embedding_size: int = 64
    chunk_size: int = 800
    chunk_overlap: int = 120

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8")


settings = Settings()
