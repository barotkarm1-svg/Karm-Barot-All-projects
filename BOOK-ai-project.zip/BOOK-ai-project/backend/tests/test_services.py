from app.services.ai import cosine_similarity
from app.services.ingestion import chunk_text, embed_text


def test_chunk_text_splits_long_input():
    text = "a" * 1000
    chunks = list(chunk_text(text, size=300, overlap=50))
    assert len(chunks) >= 3
    assert all(len(c) <= 300 for c in chunks)


def test_embed_text_fixed_vector_size():
    v = embed_text("Book AI")
    assert len(v) == 64
    assert all(isinstance(x, float) for x in v)


def test_cosine_similarity_self():
    v = [0.1, 0.2, 0.3]
    assert round(cosine_similarity(v, v), 5) == 1.0
